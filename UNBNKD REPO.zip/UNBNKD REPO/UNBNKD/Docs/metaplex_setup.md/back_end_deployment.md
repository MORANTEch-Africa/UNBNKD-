# Backend API Deployment Guide

## Steps:

1. **Install Node.js**:
   Install Node.js if it's not installed:
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_14.x | sudo -E bash -
   sudo apt-get install -y nodejs