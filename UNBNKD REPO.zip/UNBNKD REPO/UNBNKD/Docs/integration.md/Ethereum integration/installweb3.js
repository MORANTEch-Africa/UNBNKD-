const transaction = await connection.requestAirdrop(keypair.publicKey, 1e9); // 1 SOL airdrop
console.log(`Airdrop transaction: ${transaction}`);