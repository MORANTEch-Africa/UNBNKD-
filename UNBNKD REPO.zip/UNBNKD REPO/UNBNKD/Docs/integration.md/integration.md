Blockchain Integration Guide

Solana Integration
Tools Used:Solana Pay SDK, Phantom Wallet, Raydium  
How to Integrate:
1. Install Solana SDK:
   bash
   npm install @solana/web3.js