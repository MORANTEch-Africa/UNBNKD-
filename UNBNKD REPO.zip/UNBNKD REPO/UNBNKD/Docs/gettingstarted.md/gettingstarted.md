# Getting Started with UNBNKD

## Prerequisites
- Node.js (v14+)
- NPM or Yarn
- Solidity compiler (e.g., Truffle or Hardhat)
- Metamask or another Ethereum-compatible wallet
- Git

## Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/yourusername/unbnkd.git
   cd unbnkd