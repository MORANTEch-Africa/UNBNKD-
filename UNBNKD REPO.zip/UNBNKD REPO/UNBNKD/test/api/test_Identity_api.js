const chai = require('chai');
const chaiHttp = require('chai-http');
const app = require('../../src/backend/index'); 

chai.use(chaiHttp);
const expect = chai.expect;

describe('Identity API Tests', () => {
    it('should verify user identity', (done) => {
        chai.request(app)
            .post('/api/identity/verify')
            .send({
                userId: 'user123',
                identityProof: 'hash_of_proof'
            })
            .end((err, res) => {
                expect(res).to.have.status(200);
                expect(res.body.status).to.equal('Identity Verified');
                done();
            });
    });
});