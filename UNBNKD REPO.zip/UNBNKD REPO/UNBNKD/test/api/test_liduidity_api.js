const chai = require('chai');
const chaiHttp = require('chai-http');
const app = require('../../src/backend/index'); 

chai.use(chaiHttp);
const expect = chai.expect;

describe('Liquidity API Tests', () => {
    it('should provide liquidity to a pool', (done) => {
        chai.request(app)
            .post('/api/liquidity/provide')
            .send({
                tokenA: 'TokenAAddress',
                tokenB: 'TokenBAddress',
                amountA: 100,
                amountB: 200
            })
            .end((err, res) => {
                expect(res).to.have.status(200);
                expect(res.body.status).to.equal('Liquidity provided successfully');
                done();
            });
    });
});