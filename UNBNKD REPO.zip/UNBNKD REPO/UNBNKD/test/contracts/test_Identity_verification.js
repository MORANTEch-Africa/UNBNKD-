const assert = require('assert');
const anchor = require('@project-serum/anchor');

describe('Identity Verification', () => {
    const provider = anchor.Provider.env();
    anchor.setProvider(provider);

    const program = anchor.workspace.IdentityVerification;

    it('should verify identity', async () => {
        const userPublicKey = provider.wallet.publicKey;
        const identityHash = 'hash_of_proof';

        await program.rpc.verifyIdentity(identityHash, {
            accounts: {
                user: userPublicKey,
                verifier: provider.wallet.publicKey
            }
        });

        // Fetch the verification state to assert that it's verified
        const state = await program.account.identityMap.fetch(userPublicKey);
        assert.equal(state.verified, true);
    });
});