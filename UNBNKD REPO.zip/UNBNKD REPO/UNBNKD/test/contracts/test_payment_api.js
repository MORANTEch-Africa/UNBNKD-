javascript
const chai = require('chai');
const chaiHttp = require('chai-http');
const app = require('../../src/backend/index'); 

chai.use(chaiHttp);
const expect = chai.expect;

describe('Payment API Tests', () => {
    it('should initiate a cross-chain payment', (done) => {
        chai.request(app)
            .post('/api/payment/initiate')
            .send({
                fromChain: 'Ethereum',
                toChain: 'Solana',
                amount: 100,
                recipient: '0xRecipientAddress'
            })
            .end((err, res) => {
                expect(res).to.have.status(200);
                expect(res.body.status).to.equal('Payment Initiated');
                done();
            });
    });
});
