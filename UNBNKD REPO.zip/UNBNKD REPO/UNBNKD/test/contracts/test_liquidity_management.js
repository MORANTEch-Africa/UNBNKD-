const assert = require('assert');
const anchor = require('@project-serum/anchor');

describe('Liquidity Management', () => {
    const provider = anchor.Provider.env();
    anchor.setProvider(provider);

    const program = anchor.workspace.LiquidityManagement;

    it('should allow providing liquidity', async () => {
        const tokenA = new anchor.web3.PublicKey('TokenAAddress');
        const tokenB = new anchor.web3.PublicKey('TokenBAddress');
        const amountA = new anchor.BN(100);
        const amountB = new anchor.BN(200);

        await program.rpc.provideLiquidity(tokenA, tokenB, amountA, amountB, {
            accounts: {
                from: provider.wallet.publicKey,
            }
        });

        // Add assertions to check liquidity provisioned
        const poolState = await program.account.liquidityPool.fetch(provider.wallet.publicKey);
        assert.equal(poolState.tokenA.toString(), '100');
        assert.equal(poolState.tokenB.toString(), '200');
    });
});