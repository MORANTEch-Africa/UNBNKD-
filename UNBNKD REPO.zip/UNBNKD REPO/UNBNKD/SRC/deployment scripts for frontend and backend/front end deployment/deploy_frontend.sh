bash
#!/bin/bash

# Install frontend dependencies
npm install

# Build the project for production
npm run build

# Serve the production files (or upload them to hosting like Netlify/Vercel)
